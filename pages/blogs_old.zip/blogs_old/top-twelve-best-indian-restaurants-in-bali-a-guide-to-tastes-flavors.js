import React from 'react'

import Head from 'next/head'
import Newsletter from '../blogs/newsletter'
import BlogRecent from "../../components/Blogs/blogrecent"
import Blogpopular from '../../components/Blogs/blogpopular';

export default function top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_flavors() {


    return (
        <div>
            <Head>
                <title>TripzyGo - Top 12 Best Indian Restaurants In Bali - Indian Vegetarian Restaurants In Bali</title>
                <meta name="description" content="Check the list of the best Indian restaurants in Bali - For the flavors, roti, and rice, Indian vegetarian restaurants for the best Indian food in Bali." />
                <meta name="keywords" content="best indian restaurants in bali, indian vegetarian restaurants in bali, best indian food in bali" />
                <meta property="og:url" content="https://www.tripzygo.in/blogs/top-twelve-best-indian-restaurants-in-bali-a-guide-to-tastes-flavors" />
                <meta property="og:title" content="Top 12 Best Indian Restaurants In Bali - Indian Vegetarian Restaurants In Bali" />
                <meta property="og:description" content="Check the list of the best Indian restaurants in Bali - For the flavors, roti, and rice, Indian vegetarian restaurants for the best Indian food in Bali" />
                <meta property="og:image" content="https://www.tripzygo.in/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/1.webp" />
                <link rel="icon" href="/icon.png" />
                <link rel="canonical" href="https://www.tripzygo.in/blogs/top-twelve-best-indian-restaurants-in-bali-a-guide-to-tastes-flavors" />

            </Head>
            {/* <section class="breadcrumb-main pb-20 pt-14" style="background-image: url(images/bg/bg1.webp);">
        <div class="section-shape section-shape1 top-inherit bottom-0" style="background-image: url(images/shape8.webp);"></div>
        <div class="breadcrumb-outer">
            <div class="container">
                <div class="breadcrumb-content text-center">
                    <h1 class="mb-3">Blog Detail 3</h1>
                    <nav aria-label="breadcrumb" class="d-block">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Blog Detail 3</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="dot-overlay"></div>
    </section> */}
            {/* <!-- BreadCrumb Ends --> 

    <!-- blog starts --> */}
            <section style={{ padding: "2.5rem 0 5rem" }} class="blog">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-lg-8 mb-4">
                            <div class="blog-single">

                                <div class="blog-wrapper">
                                    <h1 class="headingblogs">Top 12 Best Indian Restaurants in Bali: A Guide to Tastes & Flavors</h1>
                                    <img src="\images\blog_images\top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors\1.webp" alt="best indian restaurants in bali" class="mb-3 rounded " />
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Bali is a fantastic location in Indonesia which makes for an ideal getaway destination decorated with sea shores and segregated at this point flawless islands. Bali and India have some normal things; however, food isn't one of them. For Indians visiting Bali for a honeymoon or a family vacation, we have got a list of the <strong className='strongfont'>best Indian restaurants in Bali</strong>. At the point when you ache for Indian food in Bali - the curry, the flavors, and roti and rice, Indian <strong className='strongfont'>vegetarian restaurants in Bali</strong> act the hero. <br /></p>
                                        <p class="mb-2">From the place to what makes the spot unique, everything is concealed in this list of the <strong className='strongfont'>best Indian restaurants in Bali</strong>, remember what you'd have to be aware of on your outing to Bali.</p>
                                        <p><strong className='strongfont'>• </strong>Gateway Of India</p>
                                        <p><strong className='strongfont'>• </strong>Queen’s Tandoor</p>
                                        <p><strong className='strongfont'>• </strong>Warung Little India</p>
                                        <p><strong className='strongfont'>• </strong>Indian Delites</p>
                                        <p><strong className='strongfont'>• </strong>Ganesha Ek Sanskriti</p>
                                        <p><strong className='strongfont'>• </strong>Indian Dhaba</p>
                                        <p><strong className='strongfont'>• </strong>Atithi</p>
                                        <p><strong className='strongfont'>• </strong>La Rouge</p>
                                        <p><strong className='strongfont'>• </strong>Bangle Bali</p>
                                        <p><strong className='strongfont'>• </strong>Spice Mantraa Indian Cuisine</p>
                                        <p><strong className='strongfont'>• </strong>Queens of India</p>
                                        <p><strong className='strongfont'>• </strong>NU Delhi</p>

                                    </div>
                                    <br></br>
                                    <br></br>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>01. </span>Gateway Of India</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/2.webp" alt="Gateway Of India Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Assuming that you're visiting top attractions in Bali, there are fair possibilities you'll coincidentally find Door of India in Seminyak, Kuta, and Sanur. Perhaps the best Indian café in Bali, Seminyak, this adventure has around five outlets across the island. In the event that you need delicious Indian food in Bali, this must be your top decision. Whether you love North Indian food or South Indian, these restaurants will fill your stomach and satisfy your spirit in a land distant from home.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Seminyak, Kuta, and Sanur</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Samosa, Tandoori Chicken, and Dal Makhani</td>

                                                            </tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Cuisine:</strong> fusion of French, Asian and Italian cuisines.</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>02. </span>Queen’s Tandoor</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/3.webp" alt="Queen’s Tandoor Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>On the off chance that you're searching for the <strong className='strongfont'>best Indian restaurants in Bali</strong>. It has Indian cooks at work, to prepare the <strong className='strongfont'>best Indian food in Bali.</strong> The spot serves delectable food, independent of the cooking. Like Passage of India, the parent chain organization oversees four <strong className='strongfont'>Indian vegetarian restaurants in Bali</strong>, three of which are named Sovereigns of India (Kuta, Nusa Dua, Ubud).</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Jalan Raya Seminyak No. 1/73A, Seminyak</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Mutton Vindaloo, Masala Dosa, Tandoori Chicken, and Fish Tikka</td></tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>03. </span>Warung Little India</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/4.webp" alt="Warung Little India Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Satisfying and charging up, the Warung Little India is beautified with bright hanging flags, banners of Indian actresses, and beautiful lights. Warung Little India is among the <strong className='strongfont'>best Indian restaurants in Bali</strong> as the food served here is the <strong className='strongfont'>best Indian food in Bali.</strong></div>

                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Indian Thali, samosa chaat, and chicken curry</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> alan Sukma No. 36, Ubud, Peliatan, Ubud, Kabupaten Gianyar</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>04. </span>Indian Delites</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/5.webp" alt="Indian Delites Bali " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Indian Delites is an endeavor of Bali Indian Food, a similar pecking order that oversees the entryway of India, one of the <strong className='strongfont'>best Indian restaurants in Bali</strong>. From North India's popular Chicken Curry to South India's dearest Masala Dosa, Indian Delitesmaster the craft of arrangement and show. The café is very much kept up with and the service is wonderful with the <strong className='strongfont'>best Indian food in Bali.</strong></div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Jl. Campuhan Sangingan, Ubud</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Chicken Curry, Dal Makhani, Paneer Tikka, and Samosa</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>05. </span>Ganesha Ek Sanskriti</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/6.webp" alt=" Ganesha Ek Sanskriti Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Situated close to Monkey Forest Ubud, Ganesha Ek Sanskriti is known for its tasteful feeling, mindful staff, and obviously scrumptious Indian food. On the off chance that you are searching for the <strong className='strongfont'>best Indian food in Bali</strong> with your family, this is the spot to be. The café Kuta likewise is respected among the <strong className='strongfont'>best Indian restaurants in Bali.</strong></div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Rogan Josh, Butter Chicken, and Biryani</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:  </strong> Jalan Monkey Forest, Padang Tegal, Mekar Sari, Ubud</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>06. </span>Indian Dhaba</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/7.webp" alt="Indian Dhaba Bali " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Indian Dhaba allows you to enjoy the <strong className='strongfont'>best Indian food in Bali</strong>. The stylistic layout is basic yet rich, and the food will help you to remember food back home. Since this is one of the <strong className='strongfont'>best Indian restaurants in Bali</strong> , it is very bustling at the end of the week; a reservation is suggested.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>

                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong>  9 am to 10 pm (all days)</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Jl. Bypass Ngurah Rai No. 123, Nusa Dua, Kuta, Benoa, Badung, Kabupaten Badung</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>07. </span>Atithi</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/8.webp" alt="Atithi Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Atithi is a Sanskrit word which implies visitor and the café is without a doubt the most incredible in-hospitality. The food is ready by Indian cooks once more, and they serve the <strong className='strongfont'>best Indian food in Bali</strong>. When in Kuta and Army, ensure to visit Atithi - one of the <strong className='strongfont'>best Indian restaurants in Bali.</strong></div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Jl. Melasti/Lebak Bena No. 6X, Legian</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Masala Chai, Dal Makhani, and Chicken Biryani</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>08. </span>La Rouge</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/9.webp" alt="La Rouge Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>La Rouge is one of the <strong className='strongfont'>best Indian restaurants in Bali</strong>. The café is finished with silk shades, superb upholstered seats, and silk curtains. The service is fast and proficient and the live music is generally all peppered to excite your mood - Other than Indian, the eatery serves the <strong className='strongfont'>best Indian food in Bali.</strong></div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>

                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> 34/1, Mall Rd, The Mall, Shimla</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Jl. Raya Candidasa, Sengkidu, Kabupaten Karangasem</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>09. </span>Bangle Bali</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/10.webp" alt="Bangle Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>The Bangle Bali is one of the best Indian restaurants in Bali which serves the <strong className='strongfont'>best Indian food in Bali</strong>. The café likewise serves Chinese and Western foods & the dance performance reflects an imaginative grace of Bollywood and Balinese culture, making it one of the <strong className='strongfont'>best Indian restaurants in Bali.</strong></div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Kawasan ITDC Lot C, Nusa Dua, Benoa</td>
                                                            </tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Hotel Willow Banks Shimla, Near Tourism Lift, Mall Road, Shimla</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>10. </span>Spice Mantraa Indian Cuisine</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/11.webp" alt="Spice Mantraa Indian Cuisine Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>The Spice Mantraa-tops the rundown of the <strong className='strongfont'>best Indian restaurants in Bali</strong> and offers a scope-of-flavorsome Indian pleasures. The diverse menu of the eateries offers the <strong className='strongfont'>best Indian food in Bali</strong>. Whether you're a veggie lover or a non-vegetarian, Spica Mantraa won't stimulate your taste buds like ever before.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Jl. Kartika No.2, Kuta, Kabupaten Badung</td>
                                                            </tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Smoked butter chicken, Lamb Rogan Josh, Biryani, and Vada Pav</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>11. </span>Queens of India</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/12.webp" alt="Queens of India Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Opened in 2008, this café is one of the <strong className='strongfont'> best Indian restaurants in Bali</strong>. Nothing better than the <strong className='strongfont'>best Indian food in Bali</strong>, and a fascinating environment. This café is very renowned in light of its wide assortment of Indian dishes. It gives choices of private dining, an open terrace, live kitchen shows, and gazebos, all in all, every one of the essential elements of high-end food. It has practical experience in serving veg and non-veg.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Mumbai Chaat, Naan</td>
                                                            </tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Jl. Kartika Plaza, Tuban, Kuta, Kabupaten Badung, Bali 80361, Indonesia</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>12. </span>NU Delhi</h4>
                                                <br></br>
                                                <img src="/images/blog_images/top_twelve_best_indian_restaurants_in_bali_a_guide_to_tastes_and_flavors/13.webp" alt="NU Delhi Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Quite possibly one of the <strong className='strongfont'>best Indian restaurants in Bali</strong>. NU Delhi is well known for its mouth-watering dishes. You can appreciate authentic Indian bites, refreshments and luxurious dinners. These <strong className='strongfont'>Indian vegetarian restaurants in Bali</strong> serve food sources without onion and garlic also. It is a must-attempt if you have any desire to taste the <strong className='strongfont'>best Indian food in Bali</strong>.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location: </strong> Seminyak, Kuta, and Sanur</td>
                                                            </tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty: </strong> Samosa, Tandoori Chicken, and Dal Makhani</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <br></br>
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Thus, these were the <strong className='strongfont'>best Indian restaurants in Bali</strong> where you should go assuming you're needing some delicious food that is basically as great as homemade food. These cafés offer the <strong className='strongfont'>best Indian food in Bali </strong>and furthermore guarantee that you don't miss your hand-crafted Indian flavors. </p>
                                    </div>
                                    <div>Check out our <a href='/international-tour-packages/bali-tour-packages' style={{ color: "Red" }} target="_blank">best Bali tour package </a> to spend holidays in Bali & don’t forget to explore the greater part of these cafés and satisfy your desire for Indian food.</div>
                                </div>
                            </div>
                        </div>

                        {/* <!-- sidebar starts --> */}
                        <div className="col-lg-4 pe-lg-3">
                            <div className="sidebar-sticky">
                                <div className="popular-post sidebar-item mb-2">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                            <li className="nav-item d-inline-block popularSectionHeading" role="presentation">
                                                <button aria-selected="false" className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button>
                                            </li>
                                        </ul>
                                        <div className="tab-content" id="postsTabContent1">
                                            <div aria-labelledby="popular-tab" className="tab-pane fade active show" id="popular" role="tabpanel">
                                                <Blogpopular></Blogpopular>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="recent-post sidebar-item mb-1">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <div className="post-tabs">
                                            <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                                <li className="nav-item d-inline-block" role="presentation">
                                                    <button aria-selected="false" className="nav-link active" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button>
                                                </li>
                                            </ul>
                                            <div className="tab-content" id="postsTabContent1">
                                                <div aria-labelledby="recent-tab" className="tab-pane fade active show" id="recent" role="tabpanel">
                                                    <BlogRecent></BlogRecent>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Newsletter></Newsletter>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script src="/js/jquery-3.5.1.min.js"></script>
            <script src="/js/bootstrap.min.js"></script>
            <script src="/js/particles.js"></script>
            <script src="/js/particlerun.js"></script>
            <script src="/js/plugin.js"></script>
            {/* <script src="/js/main.js"></script> */}
            <script src="/js/custom-accordian.js"></script>
            <script src="/js/custom-nav.js"></script>
            <script src="/js/custom-navscroll.js"></script>
        </div>
    )
}
