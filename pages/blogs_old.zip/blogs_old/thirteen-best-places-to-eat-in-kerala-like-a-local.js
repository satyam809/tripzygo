import React from 'react'

import Head from 'next/head'
import Newsletter from '../blogs/newsletter'
import BlogRecent from "../../components/Blogs/blogrecent"
import Blogpopular from '../../components/Blogs/blogpopular';

export default function thirteen_best_places_to_eat_in_kerala_like_a_local() {


    return (
        <div>
            <Head>
                <title>TripzyGo - 13 Best Restaurants to eat famous food in Kerala</title>
                <meta name="description" content="There are a lot of the best places to eat in Kerala. If you want to taste the famous food in Kerala, then you surely visit these 10 best restaurants in Kerala." />
                <meta name="keywords" content="best restaurants in kerala, best places to eat in kerala, famous food in kerala" />
                <meta property="og:url" content="https://www.tripzygo.in/blogs/thirteen-best-places-to-eat-in-kerala-like-a-local" />
                <meta property="og:title" content="13 Best Restaurants to eat famous food in Kerala" />
                <meta property="og:description" content="There are a lot of the best places to eat in Kerala. If you want to taste the famous food in Kerala, then you surely visit these 10 best restaurants in Kerala" />
                <meta property="og:image" content="https://www.tripzygo.in/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/1.webp" />
                <link rel="icon" href="/icon.png" />
                <link rel="canonical" href="https://www.tripzygo.in/blogs/thirteen-best-places-to-eat-in-kerala-like-a-local" />
            </Head>
            {/* <section class="breadcrumb-main pb-20 pt-14" style="background-image: url(images/bg/bg1.webp);">
        <div class="section-shape section-shape1 top-inherit bottom-0" style="background-image: url(images/shape8.webp);"></div>
        <div class="breadcrumb-outer">
            <div class="container">
                <div class="breadcrumb-content text-center">
                    <h1 class="mb-3">Blog Detail 3</h1>
                    <nav aria-label="breadcrumb" class="d-block">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Blog Detail 3</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="dot-overlay"></div>
    </section> */}
            {/* <!-- BreadCrumb Ends --> 

    <!-- blog starts --> */}
            <section style={{ padding: "2.5rem 0 5rem" }} class="blog">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-lg-8 mb-4">
                            <div class="blog-single">

                                <div class="blog-wrapper">
                                    <h1 class="headingblogs">13 Best Places to Eat in Kerala Like a Local</h1>
                                    <img src="\images\blog_images\thirteen_best_places_to_eat_in kerala_like_a_local\1.webp" alt="best restaurants in kerala" class="mb-3 rounded " />
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">As we contemplate 'God's Own Country’, Kerala, we generally imagine the backwaters, houseboats, and sea shores. What we don't think about is the wide variety of luxurious Kerala food. From Karimeen Pollicahthu to Puttu, from Appam to different kinds of fish and some<strong className='strongfont'> famous food in Kerala</strong>, the choices are endless. Practically every one of the Malayalam foods is made in coconut oil, which thus gives an exceptionally true taste of <strong className='strongfont'>famous food in Kerala</strong>. <br /></p>
                                        <p class="mb-2">There is likewise a great deal of purpose of tamarind and curry leaves in the foods. Best of all, there are so many<strong className='strongfont'> best restaurants in Kerala</strong>best restaurants in Kerala; hence, you won't ever miss the mark concerning choices with regard to tasting the neighborhood food in Kerala. </p>
                                        <p class="mb-2">Allow us to examine the best places to eat in Kerala that you should visit once when you are in the state.</p>

                                        <p><strong className='strongfont'>• </strong>Grand Pavilion</p>
                                        <p><strong className='strongfont'>• </strong>Indian Coffee House</p>
                                        <p><strong className='strongfont'>• </strong>Kethal’s Chicken</p>
                                        <p><strong className='strongfont'>• </strong>Shala Restaurant</p>
                                        <p><strong className='strongfont'>• </strong>Rahmathullah Hotel</p>
                                        <p><strong className='strongfont'>• </strong>Rapsy Restaurant</p>
                                        <p><strong className='strongfont'>• </strong>Menorah</p>
                                        <p><strong className='strongfont'>• </strong>Hotel Annapoorna</p>
                                        <p><strong className='strongfont'>• </strong>Dal Roti</p>
                                        <p><strong className='strongfont'>• </strong>Beatles Restaurant</p>
                                        <p><strong className='strongfont'>• </strong>Kashi Art Café</p>
                                        <p><strong className='strongfont'>• </strong>German Bakery</p>
                                        <p><strong className='strongfont'>• </strong>Le Sante Café</p>
                                    </div>
                                    <br></br>
                                    <br></br>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>01. </span>Grand Pavilion</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/2.webp" alt=" Grand Pavilion Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>As we discuss Kerala food heavens, we can't simply just miss out on this food paradise if you are looking for the best restaurants in Kerala. It is one of the most established food diners in Kochi where you can arrange the absolute most heavenly dishes like Karimeen Pollichathu, Biriyani, Fish, and so on. You will likewise get different Syrian food choices here.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Ernakulam, Kochi</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Karimeen Pollichathu, Biriyani, Seafood, etc.</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>02. </span>Indian Coffee House</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/3.webp" alt=" Indian Coffee House Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Indian Coffee House is one of the oldest eateries and best restaurants in Kerala. Furthermore, on the off chance that you live in or visit Trivandrum, it is a must-visit place. The channel espresso served here is invigorating. You can likewise arrange some dosa and idli here.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Filter coffee, Idli, and Dosa</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Central Station Road, Trivandrum</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>03. </span>Kethal’s Chicken</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/4.webp" alt="Kethal’s Chicken Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Assuming you have caught wind of Kerala's fried chicken and want to try famous food in Kerala, you should visit Kethal's Chicken. They have been serving since around 1949 and are possibly the most sought-after café in Trivandrum. You should definitely try chicken fry with chapati at this one of the <strong className='strongfont'>best places to eat in Kerala.</strong></div>

                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Chicken fry with chapati</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Rahmaniya Lane, Chalai Bazar,Trivandrum</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>04. </span>Shala Restaurant</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/5.webp" alt="Shala Restaurant Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>If you miss home-prepared food, you can try the famous food in Kerala at Shala Restaurant without even batting an eye. The expert chefs of this restaurant are local housewives, who cook legitimate home-style famous food in Kerala. You might try and track down lengthy lines in the café to get a table. </div>
                                                <div>A portion of the extraordinary dishes here is kingfish steak and Malabar prawn curry.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong>  Peter Celli Street, Fort Kochi, Kochi</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong>  Kingfish steak and Malabar prawn curry</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>05. </span>Rahmathullah Hotel</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/6.webp" alt="Rahmathullah Hotel Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>If you are searching for the best biryani & best restaurants in Kerala, you should visit Rahmathullah Hotel. Started around 1948, Rahmathullah hotel is a most loved eatery of numerous in Kochi, particularly the biryani darlings. They offer a wide range of biryani; be that as it may, some of them are served on specific days of the week. For instance, on Fridays, you will get fish biryani, while on Tuesdays, you will get prawn biryani. On different days of the week, you will get chicken and sheep biryani which are some famous food in Kerala.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Fish biryani, Prawn biryani</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Aanavaadal, Fort Kochi, Mattancherry, Kochi</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>06. </span>Rapsy Restaurant</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/7.webp" alt="Rapsy Restaurant Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>We as a whole attempt to try not to eat out toward the month's end, however, in the event that you want to eat some great & famous food in Kerala during those days, you can visit Rapsy Café. Dishes like biryani and Rapsy's exceptional paratha are some famous food in Kerala, starting at just Rs 50. Might it be said that you are now making your arrangement to visit Rapsy now?</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Main Bazaar, Munnar</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Biryani and Rapsy’s special paratha</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>07. </span>Menorah</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/8.webp" alt=" Menorah Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>While you search for the best restaurants in Kerala, you can visit Menorah beyond question as it is one of the best places to eat in Kerala. Here you will get a wide assortment of fish and new fish. You can likewise attempt the Jewish food here at Menorah.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Koder House, Fort Cochin, Kochi</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Jewish food, Sea Food, Fish, etc.</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>08. </span>Hotel Annapoorna</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/9.webp" alt="  Hotel Annapoorna Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Kerala is renowned for dishes like prawn curry, fish chemmeen curry, and so on. In any case, on the off chance that you are a veggie-lover, you don't need to feel terrible, as there are various vegan choices too & best places to eat in Kerala. From puttu to masala dosa, and even idli, you can arrange any vegan dish here, and you will get it.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Perumbavoor, Kerala</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Prawn curry, Seafood Chemmeen Curry, etc.</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>09. </span>Dal Roti</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/10.webp" alt="Dal Roti Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Every one of the individuals who are feeling the loss of the North Indian indulgences and want to try some famous food in Kerala can visit Dal Roti. Whether it is roasted chicken or dal makhani, you will get practically every one of the North Indian dishes here and every one of them tastes bona fide.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Fort Kochi, Kochi</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Tandoori Chicken or Dal Makhni</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>10. </span>Beatles Restaurant</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/11.webp" alt="Beatles Restaurant Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Tourists generally visit the Beatles to enjoy the famous food in Kerala. Neglecting the lighthouse beach, this restaurant is ideal for people who need to loosen up while having probably the best burgers. You will likewise get mainland breakfast here as it is one of the best restaurants in Kerala. Thus, next time you need to snatch a few burgers, you know where to visit.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Burgers</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Lighthouse Beach, Kovalam</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>11.</span>Kashi Art Café</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/12.webp" alt="Kashi Art Café Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Kashi Art Café is fascinating and has some famous food in Kerala. The aesthetic setting at this spot is something you should observe, particularly assuming you are an art lover. Aside from this, they additionally serve the absolute most divine dishes. You should try coffee and western breakfast at this one of the best restaurants in Kerala.</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> Fort Kochi, Kochi</td>
                                                            </tr>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong>  Coffee and Western Breakfast</td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>12. </span>German Bakery</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/13.webp" alt="German Bakery Kerala " class="mb-3 rounded " />
                                                <br></br>
                                                <div>While planning to visit the best places to eat in Kerala, don't miss out on German Bakery. They offer the best breakfast & menu in Kovalam. The food things they spend significant time in pizza, fish, and tofu, give some examples</div>
                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Pizza, Seafood, Tofu, etc.</td></tr>
                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong>  Lighthouse Beach, Kovalam</td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>13. </span>Le Sante Café</h4>
                                                <br></br>
                                                <img src="/images/blog_images/thirteen_best_places_to_eat_in kerala_like_a_local/14.webp" alt="Le Sante Café Kerala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Whether you need finger-licking burgers or waffles, you can head to Le Sante Café in Kozhikode. They likewise offer a few heavenly sweets.</div>

                                                <br></br>
                                                <div className="tour-includes">
                                                    <table>
                                                        <tbody>
                                                            <tr><td><i class="fa fa-group pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Specialty:</strong> Burgers or Waffles</td></tr>

                                                            <tr>
                                                                <td><i class="fa fa-map-signs pink mr-1" aria-hidden="true"></i><strong className='strongfont'>Location:</strong> NIT Mukkam Road, Kozhikode</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                    <br></br>
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Kerala is a place that is known for flavors and these flavors impact the different foods which can be found at the restaurants in the state. While you are traveling in Kerala, you can visit the best <strong className='strongfont'>places to eat in Kerala</strong> and partake in some lip-smacking luxuries when you are in the state.</p>
                                        <p class="mb-2">Planning a trip to Kerala anytime soon? Don’t forget to check out the <a href="https://www.tripzygo.in/packages" style={{ color: "Red" }} target="_blank"> best Kerala tour package</a> to enjoy your vacation hassle-free.</p>
                                    </div>

                                </div>
                            </div>
                        </div>

                        {/* <!-- sidebar starts --> */}
                        <div className="col-lg-4 pe-lg-3">
                            <div className="sidebar-sticky">
                                <div className="popular-post sidebar-item mb-2">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                            <li className="nav-item d-inline-block popularSectionHeading" role="presentation">
                                                <button aria-selected="false" className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button>
                                            </li>
                                        </ul>
                                        <div className="tab-content" id="postsTabContent1">
                                            <div aria-labelledby="popular-tab" className="tab-pane fade active show" id="popular" role="tabpanel">
                                                <Blogpopular></Blogpopular>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="recent-post sidebar-item mb-1">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <div className="post-tabs">
                                            <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                                <li className="nav-item d-inline-block" role="presentation">
                                                    <button aria-selected="false" className="nav-link active" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button>
                                                </li>
                                            </ul>
                                            <div className="tab-content" id="postsTabContent1">
                                                <div aria-labelledby="recent-tab" className="tab-pane fade active show" id="recent" role="tabpanel">
                                                    <BlogRecent></BlogRecent>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Newsletter></Newsletter>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script src="/js/jquery-3.5.1.min.js"></script>
            <script src="/js/bootstrap.min.js"></script>
            <script src="/js/particles.js"></script>
            <script src="/js/particlerun.js"></script>
            <script src="/js/plugin.js"></script>
            {/* <script src="/js/main.js"></script> */}
            <script src="/js/custom-accordian.js"></script>
            <script src="/js/custom-nav.js"></script>
            <script src="/js/custom-navscroll.js"></script>
        </div>
    )
}
