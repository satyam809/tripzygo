import React from 'react'
import Head from 'next/head'
import Newsletter from './newsletter'
import BlogRecent from "../../components/Blogs/blogrecent"
import Blogpopular from '../../components/Blogs/blogpopular';

export default function things_to_see_in_dharamshala() {
    return (
        <div>
            <Head>
                <title>TripzyGo -  10 Amazing Places to Visit in Dharamshala | Things to See in Dharamshala</title>
                <meta name="description" content="Discover the best places to visit in Dharamshala, India. Explore the top 10 things to see in Dharamshala. Let us guide you through Dharamshala attractions." />
                <meta name="keywords" content=" places to visit in dharamshala, dharamshala tourist places, places to visit near dharamshala, places to see in dharamshala, best places to visit in dharamshala, places in dharamshala, dharamshala famous places, things to see in dharamshala, dharamshala best places to visit, best places in dharamshala, dharamshala sightseeing places, dharamshala attractions, tourist attractions in dharamshala, places to go in dharamshala" />
                <link rel="icon" href="/icon.png" />
                <link rel="canonical" href="https://www.tripzygo.in/blogs/places-to-visit-in-dharamshala" />

                {/* Article Schema */}
                {/* <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            "@context": "http://schema.org",
                            "@type": "Article",
                            "name": "10 Top Things to do in Vietnam",
                            "datePublished": "2023-05-02",
                            "image": "https://www.tripzygo.in/images/blog_images/things_to_see_in_dharamshala/1.webp",
                            "articleSection": "Ho Chi Minh City: Explore its bustling streets Take a Cruise on HaLong Bay Visit the Ancient City of Hoi An Trek through the Stunning Sapa Region Experience the Vibrant Culture of Hue Discover the beauty of Nha Trang's beaches Explore the Majestic Mekong Delta Marvel at the Natural Wonders of Phong Nha-Ke Bang National Park Indulge in the Delicious Cuisine of Vietnam Experience the Festivals and Celebrations of Vietnam",
                            "articleBody": "This blog highlights the top 10 best things to do in Vietnam, from exploring ancient landmarks to indulging in delicious cuisine. Whether you're interested in bustling cities or tranquil countryside, there is something for every type of traveler in Vietnam. Let's dive in and explore the unique culture and traditions of this fascinating country!",
                            "url": "https://www.tripzygo.in/blogs/top-things-to-do-in-vietnam",
                            "publisher": {
                              "@type": "Organization",
                              "name": "TripzyGo"
                          }
                          
                          
                        })
                    }}
                /> */}
            </Head>


            <section style={{ padding: "2.5rem 0 5rem" }} class="blog">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-lg-8 mb-4">
                            <div class="blog-single">
                                <div class="blog-wrapper">
                                    <h1 class="headingblogs">10 Captivating Places to Visit in Dharamshala</h1>
                                    <img src="\images\blog_images\things_to_see_in_dharamshala\1.jpg" alt="10 Captivating Places to Visit in Dharamshala" class="mb-3 rounded " />
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Nestled amidst the breathtaking peaks of the Himalayas, Dharamshala in Himachal Pradesh stands as a serene and enchanting destination that beckons travelers from all corners of the globe. Dharamshala tourist places known for its spiritual aura, vibrant Tibetan culture, and awe-inspiring natural beauty, this hill town has earned its place as a must-visit destination in India.

                                        </p>
                                        <p class="mb-2">Whether you seek spiritual awakening, adventurous trails, or a deeper connection with nature, 10 places to visit in Dharamshala will leave you spellbound. Get ready to create cherished memories and embark on a journey that will touch your soul in this hidden gem of the Himalayas. Enjoy these places to see in Dharamshala.

                                        </p>
                                        {/* <p class="mb-2">That's why we've put together a list of the top 10 things to do in Spain, to help you make the most of your visit. From the iconic architecture of Barcelona to the beaches of the Costa del Sol, these best things to do in Spain are sure to create lasting memories.
                                        </p> */}

                                    </div>
                                    {/* <h2 >Top Things to Do in Vietnam</h2>
                                    <p class="mb-2">This blog highlights the top 10 best things to do in Vietnam, from exploring ancient landmarks to indulging in delicious cuisine. Whether you're interested in bustling cities or tranquil countryside, there is something for every type of traveler in Vietnam. Let's dive in and explore the unique culture and traditions of this fascinating country!
                                    </p>
                                    <div class="blog-content first-child-cap">
                                      <p><strong className='strongfont'>• </strong>Ho Chi Minh City: Explore its bustling streets</p>
                                      <p><strong className='strongfont'>• </strong>Take a Cruise on HaLong Bay</p>
                                      <p><strong className='strongfont'>• </strong>Visit the Ancient City of Hoi An</p>
                                      <p><strong className='strongfont'>• </strong>Trek through the Stunning Sapa Region</p>
                                      <p><strong className='strongfont'>• </strong>Experience the Vibrant Culture of Hue</p>
                                      <p><strong className='strongfont'>• </strong>Discover the beauty of Nha Trang's beaches</p>
                                      <p><strong className='strongfont'>• </strong>Explore the Majestic Mekong Delta</p>
                                      <p><strong className='strongfont'>• </strong>Marvel at the Natural Wonders of Phong Nha-Ke Bang National Park</p>
                                      <p><strong className='strongfont'>• </strong>Indulge in the Delicious Cuisine of Vietnam</p>
                                      <p><strong className='strongfont'>• </strong>Experience the Festivals and Celebrations of Vietnam</p>
                                     
                                  </div> */}
                                    <br></br>
                                   
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}}  class="mb-0"><span>01. </span>McLeod Ganj: Where Spirituality Meets Tibetan Culture</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\2.jpg" alt="McLeod Ganj: Where Spirituality Meets Tibetan Culture" class="mb-3 rounded " />
                                                <br></br>
                                                <div>McLeod Ganj, the residence of His Holiness the 14th Dalai Lama, is a vibrant town that exudes spirituality and Tibetan culture. The town is adorned with enchanting monasteries, such as Namgyal Monastery and Tsuglagkhang Complex, where visitors can witness peaceful rituals and immerse themselves in the serene beauty of the Bhagsunag Waterfall. The colorful prayer flags fluttering in the wind and the soothing chants create an atmosphere of tranquility and introspection. Exploring the vibrant streets of McLeod Ganj, lined with Tibetan shops and bustling with activity, offers an opportunity to discover unique handicrafts, and artifacts, and taste delicious Tibetan cuisine. The blend of spirituality, cultural richness, and natural beauty makes McLeod Ganj one of the best places to visit in Dharamshala.
                                                </div>
                                                {/* <div>One of the top attractions in the city is the War Remnants Museum, which showcases the brutal history of the Vietnam War. You can also visit the Reunification Palace, a symbol of the city's history and political past. The Ben Thanh Market is a must-visit destination for shopping enthusiasts, where you can find everything from silk to spices.
                                                </div> */}
                                                {/* <div>A visit to the temple is one of the best things to do in Italy, as the temples overlook the town below, and you can take in the spectacular panoramas as you tour the ancient site.</div> */}

                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>02. </span>Trek to Triund: Adventure Amidst Majestic Mountains</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\3.jpg" alt="Trek to Triund: Adventure Amidst Majestic Mountains" class="mb-3 rounded " />
                                                <br></br>
                                                <div>For adventure enthusiasts and nature lovers, a trek to Triund is a thrilling experience and one of the Dharamshala famous places to explore. The moderate trek takes you through lush forests, and meandering trails, and rewards you with breathtaking panoramic views of the snow-capped Dhauladhar Range and the picturesque Kangra Valley. As you ascend, the air becomes crisp, and the surrounding mountains seem to touch the sky. Spending a night camping under the starry sky amidst the serene mountains is an unforgettable experience. Wake up to a mesmerizing sunrise that paints the Himalayan peaks in hues of gold, and let the tranquility of the surroundings seep into your soul. Triund offers a perfect blend of adventure, natural beauty, and a sense of accomplishment.</div>
                                                {/* <div>During your cruise, you can stop at some of the many islands and explore the caves and beaches. You can also go kayaking and swimming in the bay. The best time to visit Ha Long Bay is from September to November when the weather is dry and cool.

                                                </div> */}
                                                {/* <div>Trekking the whole route needs energy, good boots, and a head for peaks as carved-in areas into closely vertical cliffs above the sea, with no railings. Trekking on this beautiful path is among the most beautiful things to do in Italy. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>03. </span>Kangra Fort: Journey Back in Time to Himalayan Grandeur </h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\4.jpg" alt="Kangra Fort: Journey Back in Time to Himalayan Grandeur " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Kangra Fort, the largest fort in the Himalayas and one of the most beautiful things to see in Dharamshala is a magnificent historical marvel that takes you on a journey back in time. Perched on a hilltop, the fort offers panoramic views of the surrounding valley and the majestic mountains. Walk through its grand entrance and explore the ancient walls, intricately carved temples, and remnants of the bygone era. The fort also houses significant shrines like the Lakshmi Narayan Temple and Ambika Devi Temple, which add a spiritual touch to your visit. As you wander through the fort's vast expanse, you can't help but feel the echoes of history and the resilience of the people who once inhabited these walls. Kangra Fort is a testament to the region's rich heritage and architectural grandeur.</div>
                                                {/* <div>Climbing Mount Vesuvius is considered one of the most adventurous things to do in Italy, and you can hike to the crater of the peak, which glimpses like something you would find on the moon's surface.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>04. </span>Bhagsunath Temple: A Serene Oasis of Spiritual Bliss

                                                </h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\5.jpg" alt="Bhagsunath Temple: A Serene Oasis of Spiritual Bliss" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Bhagsunath Temple, dedicated to Lord Shiva, is a sacred place that offers a serene and spiritual experience. This one of the Dharamshala best places to visit is known for its tranquil atmosphere and the holy water pool, believed to have healing properties. Visitors can take a dip in the pool and seek blessings for spiritual rejuvenation. The temple complex also features a beautiful waterfall, the Bhagsunag Waterfall, which cascades gracefully amidst the lush greenery. The sound of gushing water and the cool mist create a refreshing ambiance. As you climb the steps to the temple, you will be greeted by the soothing aroma of incense and the musical chants, transporting you to a state of inner peace and tranquility. Bhagsunath Temple is a place where devotion and nature's beauty harmoniously merge.</div>
                                                {/* <div>You can go trekking, which is one of the best things to do in Vietnam, through the rice fields and visit the local hill tribe villages to learn about their unique culture and way of life. The best time to visit Sapa is from September to November when the rice fields are at their most beautiful.</div> */}
                                                {/* <div>Three towns sit at the lake crossing named; Bellagio, Menaggio, and Varenna. The meeting resembles branches of a tree and can bring you to many places, ideal for an adventure of a lifetime. Sitting around the lake and admiring the view is one of the most precious things to do in Italy.
                                                </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>05. </span>Dal Lake: Nature's Retreat in Dharamshala</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\6.jpg" alt="Dal Lake: Nature's Retreat in Dharamshala" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Dharamshala boasts its own serene Dal Lake, surrounded by towering deodar trees and offering a peaceful retreat. This one of the best places in Dharamshala to visit is a perfect spot for boating and picnicking amidst nature's serenity. Rent a paddleboat or a rowboat and navigate the calm waters, taking in the breathtaking views of the surrounding mountains. The reflection of the lush greenery and the clear blue sky on the lake's surface creates a captivating sight. Enjoy a leisurely stroll along the lakeshore, breathe in the fresh mountain air, and soak in the tranquility of this natural gem.</div>
                                                {/* <div>One of the top attractions in Hue is the Imperial City, a sprawling complex of palaces and temples that was once the home of the emperor. You can also visit the Thien Mu Pagoda as this is one of the top things to do in Vietnam, a seven-story temple that overlooks the Perfume River. Don't forget to try the local specialty, Bun Bo Hue, a spicy noodle soup that is famous in the region.


                                                </div> */}
                                                {/* <div>The island is grassland for the fun-loving adult with a fondness for better things. The island is counted as Italy's best tourist attraction. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>06. </span>Norbulingka Institute: Preserving Tibetan Art and Culture</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\7.jpg" alt="Norbulingka Institute: Preserving Tibetan Art and Culture" class="mb-3 rounded " />
                                                <br></br>
                                                <div>The Norbulingka Institute is one of the amazing Dharamshala sightseeing places, a haven for art and culture enthusiasts. This center is dedicated to preserving Tibetan heritage and offers a fascinating insight into Tibetan art forms. Explore the intricately painted Thangka scrolls, observe skilled artisans creating beautiful wood carvings, and immerse yourself in the vibrant colors of traditional Tibetan crafts. The institute also boasts meticulously maintained gardens, providing a peaceful atmosphere for contemplation. Take a meditative walk amidst the blooming flowers and flowing streams, or participate in a workshop to learn traditional Tibetan art techniques. The Norbulingka Institute is a true embodiment of Tibetan craftsmanship and is a must-visit for those seeking a deeper understanding of Tibetan culture.
</div>
                                                {/* <div>One of the top attractions in Nha Trang is the Vinpearl Amusement Park, a large entertainment complex located on an island just off the coast. You can also go snorkeling and scuba diving to explore the colorful coral reefs and marine life.</div> */}
                                                {/* <div>But make sure to have strong footwear, respect the area, and don't mess up or do other activities that can damage this maintained city. Must visit when you are on a trip to Italy. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>07. </span>Dharamshala Cricket Stadium: Sports and Scenic Spectacle</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\8.jpg" alt="Dharamshala Cricket Stadium: Sports and Scenic Spectacle" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Nestled amidst the breathtaking Himalayan landscape, the Dharamshala Cricket Stadium is one of the unique Dharamshala attractions for sports enthusiasts. Known for its picturesque setting, it is one of the highest cricket grounds in the world. The stadium has hosted several international matches and is a beloved venue for both players and spectators. Even if you're not able to catch a live match, a guided tour of the stadium offers an opportunity to explore the facilities and soak in the ambiance. Stand on the lush green field, surrounded by majestic mountains, and imagine the excitement of a roaring crowd during a thrilling match. The Dharamshala Cricket Stadium combines the love for sports with the awe-inspiring beauty of its surroundings, creating a memorable experience for visitors.
                                                </div>
                                                {/* <div>You can try one of the amazing things to do in Vietnam which is to take a boat tour through the delta and visit the floating markets to see the locals buying and selling goods from their boats. You can also visit the traditional villages to see how they make rice paper, coconut candy, and other local specialties.</div> */}
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>08. </span>Tea Gardens of Dharamshala: Sip the Essence of Himalayan Tea</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\9.jpg" alt="Tea Gardens of Dharamshala: Sip the Essence of Himalayan Tea" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Indulge in the aromatic world of tea at the lush tea gardens of Dharamshala. Embark on a guided tour of the tea estates and discover the fascinating process of tea production. Walk through the neatly lined rows of tea bushes, as the experienced tea pluckers demonstrate their skill. Learn about the various tea varieties and the nuances of tea processing, from withering and rolling to drying and sorting. The verdant hills, fresh mountain air, and the gentle rustling of the tea leaves create a captivating ambiance. As you sip on a cup of freshly brewed tea, you'll appreciate the unique flavors and aromas that make this tea region renowned. The tea gardens of Dharamshala offer a delightful sensory experience and a chance to connect with nature's bounty.
                                                </div>
                                                {/* <div>The most popular cave to visit is Hang Son Doong, the largest cave in the world. You can also visit the Paradise Cave, the Phong Nha Cave, and the Dark Cave. The park is also home to many endangered species, including tigers, elephants, and monkeys.
                                                </div> */}
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>09. </span>St. John in the Wilderness Church: Gothic Charm in the Forest</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\10.jpg" alt="St. John in the Wilderness Church: Gothic Charm in the Forest" class="mb-3 rounded " />
                                                <br></br>
                                                <div>This one of the beautiful tourist attractions in Dharamshala nestled amidst the serene deodar forests, St. John in the Wilderness Church is a historic gem that showcases exquisite Gothic architecture. Built-in 1852, the church offers a peaceful haven for reflection and spiritual contemplation. Step inside to admire the stained glass windows that bathe the interior in a kaleidoscope of colors. The intricately carved wooden interiors and the tranquil atmosphere create a sense of tranquility. The church's location amidst the wilderness adds to its charm, offering a serene escape from the bustling world. Take a moment to sit in silence, soak in the beauty of the surroundings, and appreciate the timeless appeal of this architectural marvel.
                                                </div>
                                                {/* <div>Some of the best things to do in Vietnam include must-try dishes like pho, a traditional soup with noodles, meat, and herbs; banh mi, a French-inspired sandwich with meat, pickled vegetables, and chili sauce; and bun cha, grilled pork with noodles and herbs. Don't forget to try the famous Vietnamese coffee, which is made with strong coffee, condensed milk, and ice.
                                                </div> */}
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>10. </span>Tibetan Museum: A Window into Tibetan History and Heritage</h3>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_see_in_dharamshala\11.jpg" alt="Tibetan Museum: A Window into Tibetan History and Heritage" class="mb-3 rounded " />
                                                <br></br>
                                                <div>The Tibetan Museum is one of the best places to go in Dharamshala, located within the Tsuglagkhang Complex, is a fascinating destination that offers a glimpse into Tibetan history, culture, and the plight of Tibetan refugees. The museum houses a rich collection of artifacts, photographs, and exhibits that narrate the story of Tibet and its people. As you explore the museum, you'll gain insights into the struggles faced by Tibetans and their incredible resilience in preserving their heritage and traditions. Engage with the displays that highlight the Tibetan way of life, the significance of Buddhism, and the contributions of the Tibetan community around the world. The museum also sheds light on the life and teachings of His Holiness the 14th Dalai Lama, offering a deeper understanding of his role as a spiritual leader and advocate for peace. Visiting the Tibetan Museum is not just an educational experience, but also an opportunity to show solidarity with the Tibetan community and appreciate their remarkable journey.
                                                </div>
                                                {/* <div>One of the top things to do in Vietnam is to experience the popular festival Tet, the Vietnamese Lunar New Year. It is a time of family reunions, feasting, and giving gifts. Another popular festival is the Mid-Autumn Festival, which celebrates the harvest and is marked by lanterns, lion dances, and mooncakes.’
                                                </div> */}
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                {/* <h3 style={{fontSize:"20px"}} class="mb-0">Are You Ready to Have Fun in Udaipur?</h3>
                                                <br></br> */}

                                                {/* <div>
                                                Spain is a country that offers a diverse range of experiences for visitors. From its stunning architecture and world-renowned art museums to its beautiful beaches and rugged mountains, Spain has something for everyone. Whether you're a history buff, a foodie, or an outdoor enthusiast, a visit to Spain is sure to be a memorable experience
                                                </div> */}
                                                <div>
                                                Dharamshala, with its enchanting landscapes, spiritual sanctuaries, and cultural riches, is a destination that captivates the hearts of visitors. Whether you seek adventure, spiritual awakening, or a deeper understanding of Tibetan heritage, 10 places to visit in Dharamshala are sure to leave a lasting impression, creating memories that will be cherished for a lifetime. Book your Dharamshala tour package and be ready for an unforgettable vacation.
                                                </div>

                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <!-- sidebar starts --> */}
                        <div className="col-lg-4 pe-lg-3">
                            <div className="sidebar-sticky">
                                <div className="popular-post sidebar-item mb-2">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                            <li className="nav-item d-inline-block popularSectionHeading" role="presentation">
                                                <button aria-selected="false" className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button>
                                            </li>
                                        </ul>
                                        <div className="tab-content" id="postsTabContent1">
                                            <div aria-labelledby="popular-tab" className="tab-pane fade active show" id="popular" role="tabpanel">
                                                <Blogpopular></Blogpopular>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="recent-post sidebar-item mb-1">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <div className="post-tabs">
                                            <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                                <li className="nav-item d-inline-block" role="presentation">
                                                    <button aria-selected="false" className="nav-link active" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button>
                                                </li>
                                            </ul>
                                            <div className="tab-content" id="postsTabContent1">
                                                <div aria-labelledby="recent-tab" className="tab-pane fade active show" id="recent" role="tabpanel">
                                                    <BlogRecent></BlogRecent>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Newsletter></Newsletter>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script src="/js/jquery-3.5.1.min.js"></script>
            <script src="/js/bootstrap.min.js"></script>
            <script src="/js/particles.js"></script>
            <script src="/js/particlerun.js"></script>
            <script src="/js/plugin.js"></script>
            {/* <script src="/js/main.js"></script> */}
            <script src="/js/custom-accordian.js"></script>
            <script src="/js/custom-nav.js"></script>
            <script src="/js/custom-navscroll.js"></script>
        </div>
    )
}