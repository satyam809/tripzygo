import React from 'react'
import Head from 'next/head'
import Newsletter from './newsletter'
import BlogRecent from "../../components/Blogs/blogrecent"
import Blogpopular from '../../components/Blogs/blogpopular';

export default function best_summer_holiday_destination_in_the_world() {
    return (
        <div>
            <Head>
                <title>TripzyGo - Best Summer Holiday Destinations in the World 2023</title>
                <meta name="description" content="Find the best summer holiday destinations in the world for 2023 with our guide to the top summer holiday destinations. Start planning your dream vacation now!" />
                <meta name="keywords" content="best summer holiday destinations in the world, best holiday destinations in the world in summer, best holiday destinations in the world, places to visit in June outside India, best summer destinations in the world, best holiday destinations in the world to visit in summer, top holiday destinations in summer, best holiday destinations in summer, best summer vacations in the world, summer vacation spots in the world, places to visit in summer outside India, best places to visit in summer in the world, best summer vacation spots, best summer holiday destinations in South India, top summer holiday destinations, best countries to visit in the summer" />
                <link rel="icon" href="/icon.png" />
                <link rel="canonical" href=" https://www.tripzygo.in/blogs/best-summer-holiday-destinations-in-the-world" />

                {/* Article Schema */}
                <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            "@context": "http://schema.org",
                            "@type": "Article",
                            "name": "Best Summer Holiday Destinations in the World 2023",
                            "datePublished": "2023-06-06",
                            "image": "https://www.tripzygo.in/images/blog_images/best_summer_holiday_destination_in_the_world/main.jpg",
                            "articleSection": "1. Switzerland 2. Bali 3. Japan 4. Thailand 5. Dubai 6. Hawaii 7. Greece 8. Iceland 9. Spain 10. Italy 11. Paris 12. India",
                            "articleBody": "Summer season represents the golden sunshine days and beckons us to experience new adventures. It has always been the season of vibrant possibilities and urges us to create vibrant memories. So, if you all are also looking for the best summer holiday destinations in the world, TripzyGo has got you covered.",
                            "url": "https://www.tripzygo.in/blogs/best-summer-holiday-destinations-in-the-world",
                            "publisher": {
                              "@type": "Organization",
                              "name": "TripzyGo"
                          }
                          
                          
                        })
                    }}
                />
            </Head>


            <section style={{ padding: "2.5rem 0 5rem" }} class="blog">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-lg-8 mb-4">
                            <div class="blog-single">
                                <div class="blog-wrapper">
                                    <h1 class="headingblogs">BEST SUMMER HOLIDAY DESTINATIONS IN THE WORLD 2023</h1>
                                    <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\main.jpg" alt="BEST SUMMER HOLIDAY DESTINATIONS IN THE WORLD 2023" class="mb-3 rounded " />
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Summer season represents the golden sunshine days and beckons us to experience new adventures. It has always been the season of vibrant possibilities and urges us to create vibrant memories. So, if you all are also looking for the best summer holiday destinations in the world, TripzyGo has got you covered. 

                                        </p>
                                        {/* <p class="mb-2">In this blog, we have curated a list of the top 8 things to do in Srinagar that will help you make the most of your visit to this beautiful city. So, pack your bags and get ready to immerse yourself in the natural beauty and rich culture of Srinagar!

                                        </p> */}
                                        {/* <p class="mb-2">That's why we've put together a list of the top 10 things to do in Spain, to help you make the most of your visit. From the iconic architecture of Barcelona to the beaches of the Costa del Sol, these best things to do in Spain are sure to create lasting memories.
                                        </p> */}

                                    </div>
                                    <h2 >Visit and explore the best summer holiday destinations in the world in 2023</h2>
                                    <p class="mb-2">Broaden your horizons and escape from the mundane by visiting these beautiful destinations and let TripzyGo be your passport to extraordinary adventures! Embark on a voyage of discoveries at the stunning destinations mentioned below:
                                    </p>
                                    <div class="blog-content first-child-cap">
                                      {/* <p class="mb-2">Here is a list of suggestions of the must to do things in Dubai for your holiday that will ensure you have an amazing time exploring the beauty and culture here. Finding things to do at this beautiful place will be easy with this list of unique things to do in Dubai, so you can get started to plan your Dubai trip as soon as possible!</p> */}
                                      <p><strong className='strongfont'>• </strong>Switzerland</p>
                                      <p><strong className='strongfont'>• </strong>Bali</p>
                                      <p><strong className='strongfont'>• </strong>Japan</p>
                                      <p><strong className='strongfont'>• </strong>Thailand</p>
                                      <p><strong className='strongfont'>• </strong>Dubai</p>
                                      <p><strong className='strongfont'>• </strong>Hawaii</p>
                                      <p><strong className='strongfont'>• </strong>Greece</p>
                                      <p><strong className='strongfont'>• </strong>Iceland</p>
                                      <p><strong className='strongfont'>• </strong>Spain</p>
                                      <p><strong className='strongfont'>• </strong>Italy</p>
                                      <p><strong className='strongfont'>• </strong>Paris</p>
                                      <p><strong className='strongfont'>• </strong>India</p>
                                  </div>
                                    <br></br>
                                   
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}}  class="mb-0"><span>01. </span>Switzerland</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\1.jpg" alt="Switzerland" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Switzerland is one of the best summer destinations to visit in June and  offers picturesque landscapes, beautiful cities, scenic views to its visitors. Switzerland welcomes its visitors with a plethora of activities for everyone and anyone, so explore this stunning destination with our <a href="/international-tour-packages/switzerland-tour-packages" style={{ color: "Red" }} target="_blank">Switzerland tour package </a>!  One can opt for Hiking on the Swiss Alps and explore the well-marked trails leading them to lush green meadows and breath-taking views. Photo enthusiasts can visit Lake Geneva by taking a boat cruise, enjoying the mesmerising views of the lake. This picturesque lake also offers adventure water sports like kayaking and windsurfing
                                                </div>
                                                <div>Also explore the city of Lucerne and witness the well preserved mediaeval architecture and stroll along the very famous Chapel bridge. Lake Lucerne is the best place to enjoy a lovely picnic with your family and friends. Indulge in Switzerland's culinary delights by embarking on a chocolate and cheese tasting tour!
                                                </div>
                                                <div>If you are a music lover, make sure not to miss out the Montreux Jazz Festival held in the month of July and enjoy live performances of renowned artists from all over the world, creating a vibrant and lively atmosphere. Rhine Falls in Switzerland will leave you in awe as you observe the cascading water and feel the mist of the waterfall close up on your face, enjoying the stunning viewpoint</div>

                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>02. </span>Bali</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\2.jpg" alt="Bali" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Bali with its lush green landscapes and stunning beaches continues to be the best summer vacation spot. Bali is renowned for its world class surfing experiences and attracts surfers from all over the world to its stunning beaches offering an opportunity to experience the thrill of this water sport. Visitors can also explore Ubud, the cultural heart of Bali and the top destination to visit this summer. Explore the vibrant market of Ubud and immerse yourself in balinese culture by attending traditional dance and music performances. </div>
                                                <div>Located on a rocky outcrop, Tanah Lot Temple offers a mesmerising sunset viewpoint and a magical atmosphere of tranquillity. For adventure lovers, Snorkeling and diving in the Gill islands provides an unforgettable experience. The cool water teams up with the vibrant and colourful coral reefs, tropical fishes and sea creatures.</div>
                                                <div>Bali is blessed with beautiful waterfalls and lush vegetation, so prepare yourself to witness pure bliss with our <a href="/international-tour-packages/bali-tour-packages" style={{ color: "Red" }} target="_blank">Bali tour package </a>! Visit the Gigit Waterfalls in the North and Tegenungan Waterfall near Ubud to witness crystal clear waters rejuvenating your senses.</div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>03. </span>Japan</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\3.jpg" alt="Japan" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Japan being the best country to visit in summer, offers stunning landscapes and culturally enriched cities and a myriad of activities to enjoy this summer. </div>
                                                <div>Attend festivals this summer in japan and enjoy the spectacular display of fireworks and traditional performances joining the locals as they celebrate their festivals. Discover the dynamic city of Tokyo and experience how futuristic inventions blend in with ancient traditions and savour the mouth-watering Japanese street food at the Tsukiji Fish market.</div>
                                                <div>Stroll through the lush bamboo groves of Arashiyama and the zen gardens of Ryoan-Ji.</div>
                                                <div>From Vibrant Festivals to tranquil atmospheres, Japan offers an experience like no other, so make your summer unforgettable with our <a href="/international-tour-packages/japan-tour-packages" style={{ color: "Red" }} target="_blank">Japan tour package </a>.</div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>04. </span>Thailand
                                                </h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\4.jpg" alt="Thailand" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Thailand is the top holiday destination in summer and offers a vibrant culture with stunning beaches and bustling cities. Visit the islands of Phuket and feel the heat of the sun on the pristine white sands and enjoy exciting activities this summer in Thailand with our <a href="/international-tour-packages/thailand-tour-packages" style={{ color: "Red" }} target="_blank">Thailand tour package </a>.</div>
                                                <div>In Thailand, explore the bustling capital city of Bangkok, the best summer holiday destination in the world and indulge in savouring the delicious street food while shopping in bustling markets. Don't forget to immerse yourself in the vibrant night markets where you can shop for local items and souvenirs.</div>
                                                <div>Visitors can also embark on an Island hopping adventure by exploring breathtaking islands scattered along the western Thailand coast offering adventurous activities like snorkelling and diving.
                                                </div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>05. </span>Dubai</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\5.jpg" alt="Dubai" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Dubai is the best holiday destination in the world and is known for its modern architecture, lively atmosphere. Experience the breathtaking views of Dubai’s skyline by visiting the iconic Burj Khalifa, the tallest building in the world. Enjoy the panoramic views Dubai has to offer to you with our<a href="/international-tour-packages/dubai-tour-packages" style={{ color: "Red" }} target="_blank"> Dubai tour package </a></div>
                                                <div>Indulge in a shopping spree at the Dubai mall and visit popular attractions such as Dubai aquarium, underwater zoo, KidZania and VR park. For something refreshing, visit the Jumeirah Beach and watch the panoramic view of the golden sand stretching along the Arabian Gulf.


                                                </div>
                                                <div>Embark on the exhilarating Desert safari and experience camel riding,sandboarding and later in the evening feast on a barbecue style dinner. Dubai also offers many water parks and theme parks so cool off in the summer with your family and friends and have a blast!</div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>06. </span>Hawaii</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\6.jpg" alt="Hawaii" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Hawaii being the best summer vacation spot in the world offers cultural rich heritage, stunning beaches and an abundance of exciting activities for all visitors. Bask in the sun and swim the crystal clear waters of Oahu, Maui and the Big Island. Hawaii is also known as the birthplace of surfing, so catch some waves and try activities like snorkelling and Scuba diving.
</div>
                                                <div>Hawaii's lush landscapes are dotted with stunning waterfalls. So, get ready to be witnessing serenic views and breathtaking waterfalls through a hiking experience to feel the beauty of these natural wonders. For a unique perspective of Hawaii’s natural beauty take a thrilling helicopter ride and experience aerial views creating unforgettable memories of your Hawaiian trip. </div>
                                                {/* <div>But make sure to have strong footwear, respect the area, and don't mess up or do other activities that can damage this maintained city. Must visit when you are on a trip to Italy. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>07. </span>Greece</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\7.jpg" alt="Greece" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Greece with its rich history, vibrant culture and beautiful landscapes proves to be a great summer holiday destination! Begin your Greek adventure by visiting iconic Greek sites like the Ancient Agora, Parthenon, Acropolis,etc. Don't forget to discover the beauty of Greek islands offering its own unique charm through breathtaking sunsets, lively nightlife and pristine beaches.
                                                </div>
                                                <div>Visit the historic sites of Delphi and Olympia and discover the birthplace of olympic games in Greece. For outdoor enthusiasts, hike through Samaria gorge which is a 16 Km hike offering spectacular panoramic views.</div>
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>08. </span>Iceland</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\8.jpg" alt="Iceland" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Iceland being the best summer holiday destination offers a wide range of activities to do for anyone and everyone. Embark on the famous golden circle tour, including Gulfloss waterfall, Geysir Geothermal Area and Thingvellir National Park. 
                                                </div>
                                                <div>Indulge in visiting Blue Lagoon and be surrounded by the milky blue mineral rich waters surrounded by lava  fields. The blue lagoon is the perfect spot to unwind and pamper yourself. Visitors can also explore the Skaftafell Nature reserve and can take a boat tour to see icebergs and the Jokulsarlon glacier lagoon.
                                                </div>
                                                <div>Visitors can also enjoy whale watching and experience the thrill of spotting gigantic whales in their natural habitats. Embrace the rugged landscapes and the charm of Iceland with our <a href="/international-tour-packages/iceland-tour-packages" style={{ color: "Red" }} target="_blank">Iceland trip packages </a></div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>09. </span>Spain</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\9.jpg" alt="spain" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Spain offers its vibrant culture and diverse landscapes to all its visitors and that is why it is one of the best places to visit in summer in the world. Possibilities of <a href="/blogs/top-things-to-do-in-spain" style={{ color: "Red" }} target="_blank">things to do in Spain</a> are endless! Visit the vibrant city of Barcelona and witness its unique architecture. Relax on the beaches of Costa Del Sol and savour the delicious catalan cuisine.
                                                </div>
                                                <div>Places like Marbella, Estepona and Nerja offer sandy shores and crystal clear waters, so don't forget to unwind on Spain’s beautiful beaches. Alhambra in Granada offers intricate architecture being a UNESCO world heritage site so book your tickets and enjoy serene courtyards and breathtaking views of the city.
                                                </div>
                                                <div>Art enthusiasts should not miss the opportunity to visit Prado museum in Madrid and discover artistic excellence of many Spanish artists. Embrace the Spanish Zest for life and immerse yourself in the local culture of Spain!</div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>10. </span>Italy</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\10.jpg" alt="Italy" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Italy with its rich history and mouth watering cuisine offers numerous activities making it the best destination to go to in summer. Visit Rome and learn more about its ancient history by exploring iconic landmarks such as the Colosseum, Palatine hills and Roman Forum. Walk in the footsteps of ancient Rome and learn about the fascinating history of Rome.
                                                </div>
                                                <div>Visitors can also discover artistic treasures by visiting Duomo and Ponto Vecchio. Embark on a scenic drive at the Amalfi coast and enjoy the stunning views it has to offer. Italy being a food lover’s paradise, offers fresh Pasta dishes, Italian Delicacies and special cooking classes to learn how to prepare traditional Italian dishes. Immerse yourself in La Dolce vita and embrace the Italian way of life with our <a href="/international-tour-packages/italy-tour-packages" style={{ color: "Red" }} target="_blank">Italy trip packages </a>
                                                </div>
                                                {/* <div>Volterra is a part of the Florence region and ruled until the 15 A.D. century. You can enjoy one of the cutest cities with the best Italy tour packages.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>11. </span>Paris</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\11.jpg" alt="paris" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Paris also known as the “city of lights” is one of the best places to visit in summer outside India. 
                                                </div>
                                                <div>No visit to Paris is complete without seeing the iconic Eiffel tower offering panoramic views of the city and a magical light show at night. Visitors can also stroll through the charming streets of Montmartre, known for its artistic heritage. Don't forget to try a classic french crepe while you are there!
                                                </div>
                                                <div>Explore the Louvre museum  which is home to a collection of beautiful art pieces, including the renowned Mona Lisa and allow yourself to discover the vast collection of various art pieces. Enjoy shopping at luxurious boutiques and stroll along the most famous champs Elysees.  Indulge in a unique culinary experience in Paris and immerse yourself in this city’s charm with our <a href="/international-tour-packages/paris-tour-packages" style={{ color: "Red" }} target="_blank">Paris packages </a></div>

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h3 style={{fontSize:"20px"}} class="mb-0"><span>12. </span>India</h3>
                                                <br></br>
                                                <img src="\images\blog_images\best_summer_holiday_destination_in_the_world\12.jpg" alt="India" class="mb-3 rounded " />
                                                <br></br>
                                                <div>If you want to experience the best summer vacation, don't forget to visit some of the best summer holiday destinations in south India.
                                                </div>
                                                <div>Explore the backwaters of Kerala and embark on a journey of utmost tranquillity through a serene houseboat cruise. Drift along the peaceful canals and lush green paddy fields and witness the unique ecosystem of kerala. 
                                                </div>
                                                <div>Visit the temples of Tamil Nadu and explore the magnificent temples known for their spiritual significance. Attend a bharatanatyam dance performance and notice the intricate movements, vivid costumes and expressive storytelling.</div>
                                                 <div>Immerse yourself in the vibrant culture of India and enjoy the warm hospitality south of India has to offer with our range of <a href="/india-tour-packages" style={{ color: "Red" }} target="_blank">India tour packages</a></div>
                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                {/* <h3 style={{fontSize:"20px"}} class="mb-0">Are You Ready to Have Fun in Udaipur?</h3>
                                                <br></br> */}

                                                {/* <div>
                                                Spain is a country that offers a diverse range of experiences for visitors. From its stunning architecture and world-renowned art museums to its beautiful beaches and rugged mountains, Spain has something for everyone. Whether you're a history buff, a foodie, or an outdoor enthusiast, a visit to Spain is sure to be a memorable experience
                                                </div> */}
                                                <div>
                                                At TripzyGo, we believe that your trips should be informative and personalised and that is why our expert team tailor each and every tour package according to your preferences ensuring an unforgettable experience! So pack your bags and get ready to embrace the unknown with TripzyGo!
                                                </div>

                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <!-- sidebar starts --> */}
                        <div className="col-lg-4 pe-lg-3">
                            <div className="sidebar-sticky">
                                <div className="popular-post sidebar-item mb-2">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                            <li className="nav-item d-inline-block popularSectionHeading" role="presentation">
                                                <button aria-selected="false" className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button>
                                            </li>
                                        </ul>
                                        <div className="tab-content" id="postsTabContent1">
                                            <div aria-labelledby="popular-tab" className="tab-pane fade active show" id="popular" role="tabpanel">
                                                <Blogpopular></Blogpopular>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="recent-post sidebar-item mb-1">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <div className="post-tabs">
                                            <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                                <li className="nav-item d-inline-block" role="presentation">
                                                    <button aria-selected="false" className="nav-link active" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button>
                                                </li>
                                            </ul>
                                            <div className="tab-content" id="postsTabContent1">
                                                <div aria-labelledby="recent-tab" className="tab-pane fade active show" id="recent" role="tabpanel">
                                                    <BlogRecent></BlogRecent>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Newsletter></Newsletter>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script src="/js/jquery-3.5.1.min.js"></script>
            <script src="/js/bootstrap.min.js"></script>
            <script src="/js/particles.js"></script>
            <script src="/js/particlerun.js"></script>
            <script src="/js/plugin.js"></script>
            {/* <script src="/js/main.js"></script> */}
            <script src="/js/custom-accordian.js"></script>
            <script src="/js/custom-nav.js"></script>
            <script src="/js/custom-navscroll.js"></script>
        </div>
    )
}