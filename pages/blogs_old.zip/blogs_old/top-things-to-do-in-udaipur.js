import React from 'react'
import Head from 'next/head'
import Newsletter from '../blogs/newsletter'
import BlogRecent from "../../components/Blogs/blogrecent"
import Blogpopular from '../../components/Blogs/blogpopular';

export default function things_to_do_in_udaipur() {
    return (
        <div>
            <Head>
                <title>TripzyGo - 20 Top Delightful Things to do in Udaipur </title>
                <meta name="description" content=" Best things to do in Udaipur- there are plenty of top things to do in Udaipur for couples & solo travelers alike. Check our guide & start planning your trip today." />
                <meta name="keywords" content=" things to do in udaipur, best things to do in udaipur, top things to do in udaipur, things to do in udaipur for couples" />
                <link rel="icon" href="/icon.png" />
                <link rel="canonical" href="https://www.tripzygo.in/blogs/top-things-to-do-in-udaipur" />

                {/* Article Schema */}
                <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            "@context": "https://schema.org",
                            "@type": "BlogPosting",
                            "mainEntityOfPage": {
                                "@type": "jpgage",
                                "@id": "https://www.tripzygo.in/blogs/top-things-to-do-in-udaipur"
                            },
                            "headline": "20 Top Delightful Things to do in Udaipur",
                            "description": "Best things to do in Udaipur- there are plenty of top things to do in Udaipur for couples & solo travelers alike. Check our guide & start planning your trip today.",
                            "image": "https://www.tripzygo.in/images/blog_images/things_to_do_in_udaipur/1.jpg",
                            "author": {
                                "@type": "Organization",
                                "name": "TripzyGo"
                            },
                            "publisher": {
                                "@type": "Organization",
                                "name": "",
                                "logo": {
                                    "@type": "ImageObject",
                                    "url": "https://www.tripzygo.in/"
                                }
                            },
                            "datePublished": "2023-03-07",
                            "dateModified": "2023-03-08"



                        })
                    }}
                />
            </Head>


            <section style={{ padding: "2.5rem 0 5rem" }} class="blog">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-lg-8 mb-4">
                            <div class="blog-single">
                                <div class="blog-wrapper">
                                    <h1 class="headingblogs">20 Top Delightful Things to do in Udaipur </h1>
                                    <img src="\images\blog_images\things_to_do_in_udaipur\1.jpg" alt="20 Top Delightful Things to do in Udaipur " class="mb-3 rounded " />
                                    <div class="blog-content first-child-cap">
                                        <p class="mb-2">Udaipur, Rajasthan is famous for its historical Havelis, tradition, and royal palaces. Udaipur is a city and tourist destination in Rajasthan, which is famous for its history, culture and its attractive places. Udaipur, the capital of Mewar was established in 1559 by Maharana Udai Singh. But historians have different general information about the date. It is the perfect destination that offers so many activities to do for your next vacation. There are many top best things to see in Udaipur, from sightseeing or touring and getting your hands on the best things to do in Udaipur as it is a great getaway for vacation lovers.
                                        </p>
                                        <p class="mb-2">If you are planning to visit Udaipur then the best time to visit this place is between September and March time as the climate is comfortable and pleasant at this time. You would love to explore as it offers the best things to see in Udaipur at this time of year with the best Udaipur tour packages.
                                        </p>
                                        {/* <p class="mb-2">We have shortlisted the best restaurants in Dubai that foodies will adore. From vegetarian dishes to non-vegetarian fare, there is something for all kinds of travelers. Take a look at these famous restaurants in Dubai to try on your Dubai trip!</p> */}

                                    </div>
                                    <h2 class="headingblogs">Top things to do in Udaipur</h2>


                                    <br></br>
                                    <br></br>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>01. </span>Pichola Lake</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\2.jpg" alt="Pichola Lake" class="mb-3 rounded " />
                                                <br></br>
                                                <div>Although it is an artificial lake, but seeing its natural view, you will not find it less than a real lake. Your trip is incomplete without taking a boat ride in the evening, as this ride will give you a unique view. In the evening, with the rays of the sun falling on the buildings and the water, the scenery everywhere becomes golden, and you will be mesmerized by its beauty. Nature lovers will love this place.
                                                </div>
                                                {/* <div>The 80 massive rooms house is equipped with 8000 objects, Dutch expression art, history, and a little Asian collection, And that's why it is included in things to do in Amsterdam.</div> */}

                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>02. </span>City Palace</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\3.jpg" alt="City Palace" class="mb-3 rounded " />
                                                <br></br>
                                                <div>This palace, situated on Lake Pichola's banks, is considered the largest palace in Rajasthan. Large luxurious rooms, hanging gardens, and museums will make you feel like a high-class royal family. Amazing sculptures and colorful photographs of the palace will introduce you to its history in a new way. If you are interested to know about ancient times, then you can come here and increase your knowledge by knowing about Maharana Udai Singh.
                                                </div>
                                                {/* <div>Situated in the heart of the city, it is a haunting yet beautiful place, it can be considered one of the best things to do in Amsterdam, carrying a collection of diaries that Anne wrote during her long days in hiding.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>03. </span>Sajjangarh Palace</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\4.jpg" alt="Sajjangarh Palace " class="mb-3 rounded " />
                                                <br></br>
                                                <div>This palace, situated on the outskirts of Udaipur, is the site of the Mewar dynasty. The palace was named after its patron, Maharana Sajjan Singh. This palace was built at the height of the Aravalli hills so that the monsoon clouds could be detected, and that is why it is also called the Monsoon Palace. Being situated at such a height, you can see the view of the whole city from here. The tiny houses of the city twinkling from above will add to the scene at night.</div>
                                                {/* <div>The canal ring consists of three rings of semi-circular channels bisected by smaller canals radiating from the center, like the spokes of the Dutch bicycle wheel. Through this ride, you can enjoy city highlights like Skinny Bridge, the Red Light District, and the Old Port. The place is best for snapping photos of the imposing architecture and exploring vistas. To discover the beautiful city from the water on this sightseeing cruise is also add to your things to do in Amsterdam list. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>04. </span>Fateh Sagar Lake</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\5.jpg" alt="Fateh Sagar Lake" class="mb-3 rounded " />
                                                <br></br>
                                                <div>The name of this lake is also included in the Udaipur scenic spot. This is the second big lake of Udaipur. Its immense beauty will give you peace of mind, a peace that you will not be able to find anywhere else. Wrapped in the sheet of beauty, your desire for this place will increase further. Boat ride and various other water sports will keep you entertained. It is divided into three parts which include- Nehru Park, Boat shaped restaurant, Zoo for kids etc.
                                                </div>
                                                {/* <div>This 5.5-hour tour departs from Amsterdam Central Station to Holland's colorful Keukenhof Gardens, a vast area with endless tulip fields, one of the country's most photographed and iconic landscapes. Choose the guided option, where a live guide accompanies the bus, including a GPS audio guide available in multiple languages. Explore one of the best things to do in Amsterdam and learn about flowers and parks, Holland, Dutch culture, and bulbous regions.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>05. </span>Vintage Car Museum</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\6.jpg" alt="Vintage Car Museum" class="mb-3 rounded " />
                                                <br></br>
                                                <div>This museum run by the descendants of Maharana Pratap is also included in the famous sightseeing places of Udaipur. Glimpses of the luxurious royal family of Mewar are clearly visible in it. You will get to see some such models of cars here which are very unique. Seeing all these cars, you can guess that the king-maharaja must have been very fond of them. If you have a keen interest in cars, then you must come here because you will not see such extinct models anywhere else.
                                                </div>
                                                {/* <div>Get up close to windmills, water bodies, cheese makers, and clog factories, and learn firsthand about the area's rich history from your professional guide. Tastings and interior tours are also included with this. Getting a glimpse of nature is also a great option for things to do in Amsterdam. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>06. </span>Jagdish Temple</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\7.jpg" alt="Jagdish Temple" class="mb-3 rounded " />
                                                <br></br>
                                                <div>This is the temple of Lord Vishnu, located in the City Palace. Experienced artists have engraved the idols here on the stone in such a way that they will speak now. The peaceful atmosphere here attracts travelers. The main idol here, in which Vishnu is made with four hands, is made of only one black stone. This idol is surrounded by four smaller idols which are of Lord Ganesha, Sun God, Goddess of Shakti, and Lord Shiva.
                                                </div>
                                                {/* <div>Enjoy your guide's engaging commentary as you sample local cheeses, ride past windmills, and try on clogs. Highlights of the tour include Zaanse he Schans, Marken fishing village, Volendam, and Church he Broek.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>07. </span>Dudh Talai Musical Garden </h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\8.jpg" alt="Dudh Talai Musical Garden " class="mb-3 rounded " />
                                                <br></br>
                                                <div>Its modern architecture and musical fountain are the centers of attraction in the entire Rajasthan. People also know it by the name of Deendayal Park. If you want to come here and see a panoramic view, then sit in the cable car and see the sunset view, which will be very pleasant to you, and this is the reason that travelers are drawn to this place. It is open seven days a week, so you can go any day and capture a picture of the setting sun with your camera.
                                                </div>
                                                {/* <div>In the afternoon, head to The Hague, the political city of Holland. It is the administrative and royal capital of the Netherlands and the seat of government.</div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>08. </span>Jaisamand Lake</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\9.jpg" alt="Jaisamand Lake" class="mb-3 rounded " />
                                                <br></br>
                                                <div>It is the second largest artificial lake in the country surrounded by the Jaisamand Wildlife Sanctuary. Apart from touching the playful waters of this lake, you will also get a chance to see some of the unique creatures and wandering birds present in the forest. Think how sweet the chirping of birds will sound like music in this peaceful environment. This lake was built by Raja Jai ​​Singh in the 17th century. This work done by the king is highly commendable.
                                                </div>
                                                {/* <div>From this open-top double-decker bus, pass eclectic neighborhoods such as the Anne Frank House, National Maritime Museum, Jordaan, and the historic Red Light District. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>09. </span>Gulab Bagh And Zoo</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\10.jpg" alt="Gulab Bagh And Zoo" class="mb-3 rounded " />
                                                <br></br>
                                                <div>This zoo is situated in Gulab Bagh. Different types of roses will be seen here. There is a small zoo in the garden itself, in which some selected animals have been kept and there is also a toy train for the attraction of children. Also, there is an artificial water stream called Kamal Talai in the garden, sitting near which you can find peace. For a religious feel, there is Navlakha Mahal inside which will immerse the elders in devotion. If you come to this one place, you will be able to see places of different interests at the same time.
                                                </div>
                                                {/* <div>From this open-top double-decker bus, pass eclectic neighborhoods such as the Anne Frank House, National Maritime Museum, Jordaan, and the historic Red Light District. </div> */}

                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>10. </span>Saheliyon-Ki-Bari</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\11.jpg" alt="Saheliyon-Ki-Bari" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    This very beautiful garden situated on the banks of Fateh Sagar Lake was built by Maharana Sangram Singh. As you can understand from the name that it was made for those friends who came with the princess after marriage. The sheet of flowers, water fountains make this place delightful. Everyone believes that if there is any most picturesque place in Udaipur then it is the place where you can visit with your family and friends or even alone.
                                                </div>


                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>11. </span>Eklingji Temple</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\12.jpg" alt="Eklingji Temple" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    This temple dedicated to Lord Shiva is situated at a distance of 22 km from Udaipur. Its indomitable architecture will leave you in awe. This is the reason why it comes on top of the list of tourist places. It is a two-storied temple whose roof has been given the shape of a pyramid. As soon as you enter the verandah of the temple, you will see a beautiful Nandi idol made of silver. Two statues will also be found inside, one made of black stone and the other of brass. The temple has a four-faced idol of Lord Shiva, which is made of black marble. This is a huge statue of 50 feet.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>12. </span>Nathdwara Temple</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\13.jpg" alt="Nathdwara Temple" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    Shrinathji is enshrined in the Lord Shrinathji temple in Nathdwara town, which was once known as Sihad village, 42 km north-east of Udaipur district of Rajasthan. The devotion of the devotees is so deep that they want to take out time and just come here. The atmosphere of devotion and peace is its most attractive thing.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>13. </span>Jag Mandir Palace</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\14.jpg" alt="Jag Mandir Palace" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    The other name of this palace made of Islamic architecture is - "The Lake Garden Palace". It is made of marble and yellow sandstone. It is surrounded by eight grand size elephant statues, as if these elephants are guarding it. This beautiful palace is situated on the southern island of Lake Pichola. The shimmering water all around and this wonderful shining palace in the middle testifies to its beauty.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>14. </span>Bada Mahal </h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\15.jpg" alt="Bada Mahal " class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    This palace built by Rajput and Mughal architecture is the part which is mainly made for men. The palace, decorated with beautiful gardens all around adds to the atmosphere. This palace, which is included in the historical palaces of Rajasthan, is an attractive sightseeing place today even after maintaining its antiquity. Because of its beautiful gardens, it is also called the Garden Palace.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>15. </span>Maharana Pratap Samarak</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\16.jpg" alt="Maharana Pratap Samarak" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    The great warrior of Indian history has great importance in Rajasthan. This monument bears testimony to his bravery. This monument has been built on the banks of Fateh Sagar Lake. Maharana Pratap sitting on Chetak tells the story of his brave sacrifice. This 11 feet high statue is made of brass. Coming to Udaipur and seeing this talented idol is a matter of pride in itself.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>16. </span>Village Shilp</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\17.jpg" alt="Village Shilp" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    Among the states of India, Rajasthan is such a state which gives great importance to art etc. and the art here is also very famous. Be it art or handicraft or traditional dance and music, puppet plays etc – all these have maintained their existence in spite of modernity. It is situated near Hawala village at a distance of 3 km from Udaipur. You will get the opportunity to see the classy artwork.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>17. </span>Nehru Garden</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\18.jpg" alt="Nehru Garden" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    Nestled in the middle of the Fateh Sagar Lake, this garden has a variety of water fountains which are similar to the Brindavan Gardens of Mysore. Imagine a floating restaurant shaped like a boat. Wait, you don't even have to imagine because it's real. You are enjoying the food while sitting in the restaurant and having a beautiful view around. Wow! There is no answer to this.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>18. </span>Bharatiya Lok Kala Mandal</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\19.jpg" alt="Bharatiya Lok Kala Mandal" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    This museum in Udaipur is very famous. The source of maintaining the Rajasthani culture which will show you a sample of the amazing heritage of the Mewar region. Some traditional items and artefacts have been preserved here. It is also a center of art education where local artists and other people know and understand art literature. You will consider yourself lucky by coming here because you will get to see such amazing artwork here.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>19. </span>Ambrai Ghat</h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\20.jpg" alt="Ambrai Ghat" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    The most famous ghat of Udaipur which is also known as Manjhi Ghat. You will see local people doing yoga and taking bath here early in the morning. Not only the local people, tourists also come here a lot. In the evening, you can make your evening beautiful by sitting here and watching the twinkling lights of the city. The melodious tone of Aarti makes the atmosphere religious.
                                                </div>


                                            </div>
                                        </div>


                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0"><span>20. </span>Haathi Pol Bazaar </h4>
                                                <br></br>
                                                <img src="\images\blog_images\things_to_do_in_udaipur\21.jpg" alt="Haathi Pol Bazaar" class="mb-3 rounded " />
                                                <br></br>
                                                <div>
                                                    You can fulfill your shopping wish by coming here. Here you will find everything from popular brands to local items. Items reflecting the tradition of Rajasthan, colorful hand-dyed Rajasthani dupattas, silver jewellery, decorative items etc. This market is mainly famous for miniature paintings, Ichchhwai paintings and hand paintings on silk cloth. You can take home a good memory from here.
                                                </div>


                                            </div>
                                        </div>


                                    </div>

                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 mb-2 ">
                                            <div className="desc-box bg-grey p-4 rounded ">
                                                <h4 class="mb-0">Are You Ready to Have Fun in Udaipur?</h4>
                                                <br></br>

                                                <div>
                                                    There are many more activities to experience in Udaipur, many more places to visit, and savour the beauty of this city, but let us leave something for your next trip, shall we? Until then, list these in your itinerary with the best <a href='/india-tour-packages/udaipur-tour-packages' style={{ color: "Red" }} target="_blank"> Udaipur tour packages</a> , and then get ready to have the best time of your life exploring the best things to do in Udaipur.
                                                </div>
                                                <div>
                                                    So, plan your next exciting vacation in India with these top things to do in Udaipur. Get in touch for the best packages and special deals to make your trip more exciting and cost-efficient.
                                                </div>

                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <!-- sidebar starts --> */}
                        <div className="col-lg-4 pe-lg-3">
                            <div className="sidebar-sticky">
                                <div className="popular-post sidebar-item mb-2">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                            <li className="nav-item d-inline-block popularSectionHeading" role="presentation">
                                                <button aria-selected="false" className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button>
                                            </li>
                                        </ul>
                                        <div className="tab-content" id="postsTabContent1">
                                            <div aria-labelledby="popular-tab" className="tab-pane fade active show" id="popular" role="tabpanel">
                                                <Blogpopular></Blogpopular>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="recent-post sidebar-item mb-1">
                                    <div className="trend-item box-shadow bg-white mb-4 rounded overflow-hidden">
                                        <div className="post-tabs">
                                            <ul className="nav nav-tabs nav-pills nav-fill" id="postsTab1" role="tablist">
                                                <li className="nav-item d-inline-block" role="presentation">
                                                    <button aria-selected="false" className="nav-link active" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button>
                                                </li>
                                            </ul>
                                            <div className="tab-content" id="postsTabContent1">
                                                <div aria-labelledby="recent-tab" className="tab-pane fade active show" id="recent" role="tabpanel">
                                                    <BlogRecent></BlogRecent>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Newsletter></Newsletter>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script src="/js/jquery-3.5.1.min.js"></script>
            <script src="/js/bootstrap.min.js"></script>
            <script src="/js/particles.js"></script>
            <script src="/js/particlerun.js"></script>
            <script src="/js/plugin.js"></script>
            {/* <script src="/js/main.js"></script> */}
            <script src="/js/custom-accordian.js"></script>
            <script src="/js/custom-nav.js"></script>
            <script src="/js/custom-navscroll.js"></script>
        </div>
    )
}